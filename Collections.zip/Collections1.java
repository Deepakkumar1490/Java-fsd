package BasicTopics;
import java.util.*;

public class Collections1 {

	public static void main(String[] args) {
	
		System.out.println("ArrayList");
		ArrayList<String> name=new ArrayList<String>();
		 name.add("kumar");
		 name.add("devi");
		 name.add("ajay");
		 System.out.println(name);
		 
		 System.out.println("\nVector");
		 Vector<Integer> a = new Vector<Integer>();
		 a.addElement(1);
		 a.addElement(5);
		 a.addElement(3);
		 System.out.println(a);
		
		 System.out.println("\nLinkedList");
		 LinkedList<String> subject=new LinkedList<String>();
		 subject.add("math");
		 subject.add("physics");
		 subject.add("chemistry");
		 System.out.println(subject);

		 System.out.println("\nHashSet");
		 HashSet<Integer> b=new HashSet<Integer>();
		 b.add(32);
		 b.add(78);
		 b.add(56);
		 System.out.println(b);

		 System.out.println("\nLinkedHashSet");
		 LinkedHashSet<Integer> c=new LinkedHashSet<Integer>();
		 c.add(6);
		 c.add(15);
		 c.add(11);
		 System.out.println(c);
		 }
		 } 
