package BasicTopics;
import java.util.*;

public class Map1 {

	public static void main(String[] args) {
		
		Map<String, Integer> a = new HashMap<>();
        a.put("Physics", 85);
        a.put("chemistry", 89);
        a.put("Maths", 92);
        System.out.println("HashMap");
        for (Map.Entry<String, Integer> e : a.entrySet())
            System.out.println(e.getKey() + " "+ e.getValue());

		 Hashtable<String,Integer> b=new Hashtable<String,Integer>();
		 b.put("Deepak", 50);
	     b.put("Kumar", 60);
	     b.put("Ramesh", 70);
		 System.out.println("\nHashTable");
		 for (Map.Entry<String, Integer> e : b.entrySet())
	            System.out.println(e.getKey() + " "+ e.getValue());
		 
		 Map<String, Integer> c = new TreeMap<>();
	     c.put("chennai", 600001);
	     c.put("Kanchipuram",600100);
	     c.put("Vellore", 601000);
	     System.out.println("\nTreeMap");
	     for (Map.Entry<String, Integer> e : c.entrySet())
	           System.out.println(e.getKey() + " "+ e.getValue());
		 }

		 }

