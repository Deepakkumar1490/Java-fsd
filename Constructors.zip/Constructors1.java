package BasicTopics;
import java.util.Scanner;

public class Constructors1 {

	    public Constructors1(int x,String l)
	    {
	    	System.out.println("Two aruguments : "+x+" "+l);
	    }
	    public Constructors1(int y, int d,String z)
	    {
	    	System.out.println("Three aruguments : "+y+" "+d+" "+z);
	    }
	public static void main(String[] args) {
		int i,j;
		String k="Constructor";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two values");
		i=sc.nextInt();
		j=sc.nextInt();
		Constructors1 a=new Constructors1(i,k);
		Constructors1 b=new Constructors1(i,j,k);
	}
}
