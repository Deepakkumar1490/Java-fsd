package String;

public class ConvertToStringBuffer {

	public static void main(String[] args) {

		String str="Hello";
		
		StringBuffer a=new StringBuffer();
		a.append(str);
		
		String str2="I am Varun";
		a.append("  "+str2);
		
		a.insert(6, "Sir");
		
		System.out.println(a);
		
		a.reverse();
		System.out.println("\nAfter Reversing the String: "+" "+a);

	}
}
