package BasicTopics;

import java.util.Scanner;

public class InnerClass {

	int i,j,k=0;
	public int mul(int i,int j)
	{
		this.i=i;
		this.j=j;
		k=this.i*this.j;
		return k;
	}
	class Val{
		void print()
		{
    	System.out.println("Mul :"+k);
    	}
	}
	public static void main(String[] args) {
		int i,j;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two values");
		i=sc.nextInt();
		j=sc.nextInt();
		InnerClass a=new InnerClass();
		InnerClass.Val b=a.new Val();
		a.mul(i,j);
		b.print();
	}
}
